
# 🧪 Run Daily Update Dashboard Locally – Step-by-Step

This project uses Docker to run a full stack (React + Node.js + PostgreSQL) with OAuth, Slack/email notifications, and a mobile app.

---

## 🔧 Step 1: Install Required Tools

You only need **Docker** to run everything locally:

- ✅ [Docker Desktop](https://www.docker.com/products/docker-desktop)

### (Optional, for Mobile App)
If you want to test the **mobile app**, also install:

- ✅ [Node.js](https://nodejs.org/)
- ✅ [Expo CLI](https://docs.expo.dev/get-started/installation/)
```bash
npm install -g expo-cli
```

---

## 📦 Step 2: Download and Unzip the Project

```bash
unzip Daily-Update-Dashboard.zip
cd Daily-Update-Dashboard
```

---

## 📁 Step 3: Set Up Environment Variables

```bash
cd server
cp .env.example .env
```

Then edit `.env`:

```env
DATABASE_URL=postgresql://postgres:postgres@db:5432/dailyupdates
JWT_SECRET=your-secret-key

EMAIL_USER=your-email@example.com
EMAIL_PASS=your-email-password
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
GOOGLE_CLIENT_ID=your-google-client-id
MICROSOFT_CLIENT_ID=your-microsoft-client-id
```

---

## 🐳 Step 4: Start the App Using Docker

```bash
cd ..
docker-compose up --build
```

✅ Starts:
- Backend: http://localhost:4000
- Frontend: http://localhost:3000

---

## 🧱 Step 5: Set Up the Database

```bash
docker-compose exec backend npx prisma migrate deploy
```

---

## ✅ Step 6: Use the App

1. Open http://localhost:3000
2. Register/login as a user
3. Submit an update
4. Log in as admin to manage submissions

---

## 🔐 Step 7: Promote a User to Admin

```sql
UPDATE "User" SET role = 'ADMIN' WHERE email = 'you@example.com';
```

---

## 📱 Step 8: Run Mobile App (Optional)

```bash
cd mobile
npx expo start
```

Scan QR code with **Expo Go** on your phone.

---

## ⚙️ Optional Setup

### 📨 Email Notifications
Enable SMTP in `.env`.

### 🔔 Slack Alerts
Paste your Slack webhook in `.env`.

---

## 🧼 Troubleshooting

- Ports in use? Free up 3000, 4000, 5432
- Reset DB:
```bash
docker-compose down -v
```

---

## 🔗 Local URLs

| Component   | URL                        |
|-------------|----------------------------|
| Frontend    | http://localhost:3000      |
| Backend     | http://localhost:4000/api  |
| Postgres DB | postgres://postgres@db:5432|
