
# 📘 Daily Update Dashboard

A full-stack work tracking platform designed for internal teams (30–50 members), where users submit daily progress updates linked to project tickets (e.g., JIRA). A program manager (admin) reviews updates, sends reminders, and receives automated summaries.

---

## ✨ Features

### 👥 User & Admin Roles
- **User**: Can submit updates, view personal history
- **Admin**: Can view all updates, approve/reject them, send reminders, and receive summary reports

### 🔐 Authentication
- Email/password login (JWT-based)
- Social login via **Google** and **Microsoft**

### 📝 Daily Update Submission
- Input fields: **JIRA ticket number**, **description**
- Supports: file attachments, markdown text
- Tracks: submission date, update status (pending, approved, rejected)

### 📊 Admin Dashboard
- Filter updates by date/user/status
- Approve/Reject with one click
- Download CSV reports
- View individual user histories

### 📬 Automated Email Summaries
- Daily at 6 PM (Mon–Fri)
- Summary of all team member updates
- Sent to all users with admin role

### 🔔 Notifications
- Slack notifications on submission or approvals
- Email reminders for missing updates (optional cron job)

---

## 🚀 Tech Stack

| Layer         | Technology                          |
|--------------|--------------------------------------|
| Frontend      | React.js + Tailwind CSS             |
| Backend       | Node.js + Express.js + Prisma ORM   |
| Database      | PostgreSQL                          |
| Mobile App    | React Native (Expo)                 |
| Authentication| JWT, Google OAuth, Microsoft OAuth  |
| DevOps        | Docker, GitHub Actions              |
| Infra-as-Code | Terraform (AWS: ECS, RDS, S3)       |
| Reverse Proxy | NGINX                               |

---

## 📦 Local Setup

### 1. Clone or unzip the project
```bash
unzip Daily-Update-Dashboard.zip
cd Daily-Update-Dashboard
```

### 2. Setup environment variables
```bash
cd server
cp .env.example .env
```

Then edit `.env` with your credentials:
```env
DATABASE_URL=postgresql://postgres:postgres@db:5432/dailyupdates
JWT_SECRET=your-secret
EMAIL_USER=your@email.com
EMAIL_PASS=email-password
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
GOOGLE_CLIENT_ID=your-google-client-id
```

### 3. Start with Docker
```bash
docker-compose up --build
```

### 4. Run Prisma Migration
```bash
docker-compose exec backend npx prisma migrate deploy
```

### 5. Open in Browser

| Service       | URL                        |
|---------------|----------------------------|
| Frontend      | http://localhost:3000      |
| Backend API   | http://localhost:4000/api  |
| PostgreSQL DB | localhost:5432             |

---

## 🔐 Admin Access

By default, users are created with role `USER`.

To promote someone to admin:
```sql
UPDATE "User" SET role = 'ADMIN' WHERE email = 'you@example.com';
```

---

## 📱 Mobile App Setup

```bash
cd mobile
npx expo start
```

Scan the QR code from your terminal with Expo Go app (Android/iOS).

---

## 🧪 Testing Flow

- Register/Login as user
- Submit update with JIRA ticket & description
- Log in as Admin → visit `/admin` to approve/reject
- Check Slack/Email if enabled
- Wait for automated 6 PM summary email

---

## 🌐 Deployment Notes

- Use `terraform/` to provision AWS infrastructure
- GitHub Actions auto-deploys on `main` branch push
- NGINX proxy handles frontend/backend under one domain

---

## 📁 Project Structure

```
Daily-Update-Dashboard/
├── client/               # React frontend
├── server/               # Express + Prisma backend
│   ├── src/routes/       # Auth, update, admin, oauth
│   ├── src/utils/        # Email, Slack helpers
│   ├── src/cron/         # Scheduled jobs
│   └── prisma/           # DB schema
├── mobile/               # React Native (Expo)
├── terraform/            # AWS infra
├── .github/workflows/    # GitHub Actions CI
├── nginx/conf.d/         # NGINX reverse proxy
├── docker-compose.yml    # Local dev
└── README.md             # This file
```

---

## 🤝 Contributing

Open an issue or PR to suggest improvements or report bugs.

---

## 📄 License

MIT — free to use, modify, and deploy commercially.
