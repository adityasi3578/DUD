import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function ProfileDropdown({ onLogout }) {
  const [user, setUser] = useState({ name: '', email: '' });
  const [editingName, setEditingName] = useState('');
  const [message, setMessage] = useState('');

  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get('http://localhost:4000/api/auth/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(res.data);
        setEditingName(res.data.name);
      } catch (err) {
        console.error('Profile fetch failed', err);
      }
    };

    fetchProfile();
  }, [token]);

  const handleSave = async () => {
    try {
      const res = await axios.put(
        'http://localhost:4000/api/auth/update-name',
        { name: editingName },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setUser(prev => ({ ...prev, name: res.data.name }));
      setMessage('Name updated!');
    } catch (err) {
      console.error('Name update failed', err);
      setMessage('Error updating name.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    onLogout(); // Trigger parent component logout
  };

  return (
    <div className="absolute top-16 right-4 bg-white dark:bg-gray-800 shadow-lg rounded-lg w-64 p-4 z-50 border border-gray-200 dark:border-gray-700">
      <h3 className="text-lg font-bold mb-3 text-gray-800 dark:text-white">Profile</h3>

      <div className="mb-3">
        <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">Name</label>
        <input
          className="w-full border px-3 py-2 rounded text-gray-900 dark:text-white bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
          value={editingName}
          onChange={e => setEditingName(e.target.value)}
        />
      </div>

      <div className="mb-3">
        <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">Email</label>
        <input
          className="w-full px-3 py-2 rounded bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600"
          value={user.email}
          readOnly
        />
      </div>

      {message && <p className="text-sm text-green-600 dark:text-green-400">{message}</p>}

      <div className="flex justify-between mt-4">
        <button
          onClick={handleSave}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded"
        >
          Save
        </button>
        <button
          onClick={handleLogout}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-1 rounded"
        >
          Logout
        </button>
      </div>
    </div>
  );
}
