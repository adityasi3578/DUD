import { useState } from "react";
import ProfileDropdown from "./ProfileDropdown";

const TopNavbar = ({ user, onLogout }) => {
  const [showDropdown, setShowDropdown] = useState(false);

  const toggleDropdown = () => setShowDropdown(prev => !prev);

  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    localStorage.theme = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
  };

  return (
    <header className="bg-gray-800 text-white flex justify-between items-center px-6 py-3 shadow-md">
      <h1 className="text-xl font-semibold">Admin Panel</h1>

      <div className="flex items-center gap-4">
        <button
          onClick={toggleTheme}
          className="text-sm px-3 py-1 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded"
        >
          Toggle Theme
        </button>

        <div className="relative">
          <div
            className="bg-indigo-600 w-10 h-10 rounded-full flex items-center justify-center cursor-pointer"
            onClick={toggleDropdown}
            title={user?.email || 'Profile'}
          >
            {user?.name?.[0]?.toUpperCase() || "A"}
          </div>

          {showDropdown && (
            <ProfileDropdown onLogout={onLogout} />
          )}
        </div>
      </div>
    </header>
  );
};

export default TopNavbar;
