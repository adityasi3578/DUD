import { Home, ClipboardList } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const Sidebar = () => {
  const location = useLocation();

  const navItems = [
    { name: "Dashboard", path: "/dashboard", icon: <Home size={20} /> },
    { name: "Updates", path: "/admin", icon: <ClipboardList size={20} /> },
  ];

  return (
    <aside className="bg-gray-900 text-white w-64 h-screen p-4">
      <div className="text-xl font-bold mb-6">MyTools Admin</div>
      <nav className="space-y-2">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center gap-2 p-2 rounded ${
              location.pathname === item.path ? "bg-gray-700" : "hover:bg-gray-800"
            }`}
          >
            {item.icon}
            <span>{item.name}</span>
          </Link>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
