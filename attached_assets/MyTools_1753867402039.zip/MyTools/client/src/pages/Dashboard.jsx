import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Dashboard() {
  const [text, setText] = useState('');
  const [ticket, setTicket] = useState('');
  const [updates, setUpdates] = useState([]);
  const [error, setError] = useState('');

  const token = localStorage.getItem('token');

  let userId;
  try {
    if (!token) throw new Error('No token found');
    userId = JSON.parse(atob(token.split('.')[1])).id;
  } catch (err) {
    localStorage.removeItem('token');
    window.location.href = '/'; // redirect to login
    return null; // stop rendering
  }

  const logout = () => {
    localStorage.removeItem('token');
    window.location.href = '/';
  };

  const fetchUpdates = async () => {
    try {
      const res = await axios.get(`http://localhost:4000/api/updates/my/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUpdates(res.data);
    } catch (err) {
      console.error('Failed to fetch updates:', err);
      setError('Failed to load updates. Please try again later.');
    }
  };

  const submitUpdate = async () => {
    try {
      await axios.post(
        'http://localhost:4000/api/updates',
        { ticketNumber: ticket, updateText: text, userId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setText('');
      setTicket('');
      fetchUpdates();
    } catch (err) {
      console.error('Failed to submit update:', err);
      setError('Failed to submit update.');
    }
  };

  useEffect(() => {
    fetchUpdates();
  }, []);

  return (
    <div>
      <h2>My Updates</h2>
      <button onClick={logout}>Logout</button>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <input
        placeholder="JIRA Ticket #"
        value={ticket}
        onChange={e => setTicket(e.target.value)}
      />
      <textarea
        placeholder="What did you do today?"
        value={text}
        onChange={e => setText(e.target.value)}
      />
      <button onClick={submitUpdate}>Submit</button>

      <ul>
        {updates.map(u => (
          <li key={u.id}>
            {new Date(u.date).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}: {u.updateText}
          </li>
        ))}
      </ul>
    </div>
  );
}
