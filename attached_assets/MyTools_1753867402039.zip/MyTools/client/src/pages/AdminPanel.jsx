import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Sidebar from '../components/Sidebar';
import TopNavbar from '../components/TopNavbar';

export default function AdminPanel() {
  const [updates, setUpdates] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [error, setError] = useState('');
  const [searchUser, setSearchUser] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [user, setUser] = useState(null); // 🟢 dynamic user

  const itemsPerPage = 5;
  const token = localStorage.getItem('token');

  const fetchUpdates = async () => {
    try {
      const res = await axios.get('http://localhost:4000/api/admin', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUpdates(res.data);
      setFiltered(res.data);
    } catch (err) {
      console.error('Error fetching updates:', err);
      setError('Unauthorized. Please login as admin.');
    }
  };

  const fetchUser = async () => {
    try {
      const res = await axios.get('http://localhost:4000/api/auth/profile', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUser(res.data);
    } catch (err) {
      console.error('Error fetching profile:', err);
    }
  };

  const actOnUpdate = async (id, action) => {
    try {
      await axios.post(`http://localhost:4000/api/admin/${id}/${action}`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchUpdates();
    } catch (err) {
      console.error(`Error updating status:`, err);
    }
  };

  const handleSearch = () => {
    let data = updates;

    if (searchUser)
      data = data.filter(u => u.user?.email?.toLowerCase().includes(searchUser.toLowerCase()));

    if (searchDate)
      data = data.filter(u => u.date?.startsWith(searchDate));

    if (statusFilter)
      data = data.filter(u => u.status === statusFilter);

    setFiltered(data);
    setPage(1);
  };

  const exportCSV = () => {
    const csvContent = `data:text/csv;charset=utf-8,${[
      ['Date', 'User', 'Ticket', 'Text', 'Status'].join(','),
      ...filtered.map(u => [
        u.date,
        u.user?.email || '',
        u.ticketNumber,
        u.updateText,
        u.status
      ].join(','))
    ].join('\n')}`;

    const encoded = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encoded);
    link.setAttribute('download', 'updates.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    window.location.href = '/login';
  };

  const handleNameChange = (newName) => {
    setUser(prev => ({ ...prev, name: newName }));
  };

  useEffect(() => {
    fetchUpdates();
    fetchUser(); // 🟢 also fetch user on mount
  }, []);

  const paginated = filtered.slice((page - 1) * itemsPerPage, page * itemsPerPage);
  const totalPages = Math.ceil(filtered.length / itemsPerPage);

  return (
    <div className="flex min-h-screen bg-gray-900 text-white">
      <Sidebar />
      <div className="flex flex-col flex-1">
        <TopNavbar
          user={user || { name: 'Admin' }}
          onLogout={handleLogout}
          onNameChange={handleNameChange}
        />
        <main className="p-4">
          <h2 className="text-2xl font-semibold mb-4">Admin Panel</h2>
          {error && <p className="text-red-500 mb-4">{error}</p>}

          <div className="mb-4 flex flex-wrap gap-2 items-center">
            <input
              className="text-black p-2 rounded"
              placeholder="Filter by user email"
              value={searchUser}
              onChange={e => setSearchUser(e.target.value)}
            />
            <input
              className="text-black p-2 rounded"
              type="date"
              value={searchDate}
              onChange={e => setSearchDate(e.target.value)}
            />
            <select
              className="text-black p-2 rounded"
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
            >
              <option value="">All</option>
              <option value="approved">✅ Approved</option>
              <option value="rejected">❌ Rejected</option>
            </select>
            <button className="bg-blue-600 px-4 py-2 rounded" onClick={handleSearch}>Search</button>
            <button className="bg-green-600 px-4 py-2 rounded" onClick={exportCSV}>Export CSV</button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full bg-gray-800 rounded shadow-md text-sm">
              <thead>
                <tr>
                  <th className="p-2 border">Date</th>
                  <th className="p-2 border">User</th>
                  <th className="p-2 border">Ticket</th>
                  <th className="p-2 border">Text</th>
                  <th className="p-2 border">Status</th>
                  <th className="p-2 border">Actions</th>
                </tr>
              </thead>
              <tbody>
                {paginated.map(u => (
                  <tr key={u.id} className="text-center">
                    <td className="p-2 border">{new Date(u.date).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td>
                    <td className="p-2 border">{u.user?.email || '-'}</td>
                    <td className="p-2 border">{u.ticketNumber}</td>
                    <td className="p-2 border">{u.updateText}</td>
                    <td className="p-2 border font-bold"
                        style={{
                          color:
                            u.status === 'approved' ? 'limegreen' :
                            u.status === 'rejected' ? 'red' : 'gray'
                        }}
                    >
                      {u.status || 'Pending'}
                    </td>
                    <td className="p-2 border space-x-2">
                      <button onClick={() => actOnUpdate(u.id, 'approved')}>✅</button>
                      <button onClick={() => actOnUpdate(u.id, 'rejected')}>❌</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex justify-between items-center">
            <span>Page {page} of {totalPages}</span>
            <div className="space-x-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-3 py-1 bg-gray-700 rounded disabled:opacity-50"
              >
                Prev
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="px-3 py-1 bg-gray-700 rounded disabled:opacity-50"
              >
                Next
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
