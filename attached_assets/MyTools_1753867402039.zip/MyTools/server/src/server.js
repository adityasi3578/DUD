require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// Base route
app.get('/', (req, res) => {
  res.send('Daily Update Dashboard API');
});

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/updates', require('./routes/updates'));
app.use('/api/oauth/google', require('./routes/oauth-google'));
app.use('/api/oauth/microsoft', require('./routes/oauth-microsoft'));
app.use('/api/admin', require('./routes/admin'));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
