const express = require("express");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const authenticateToken = require("../middleware/auth");
const router = express.Router();

router.post("/", authenticateToken, async (req, res) => {
  const { ticketNumber, updateText } = req.body;
  const userId = req.user.id;

  const update = await prisma.dailyUpdate.create({
    data: { ticketNumber, updateText, userId, date: new Date() }
  });
  res.json(update);
});

router.get("/my/:userId", authenticateToken, async (req, res) => {
  const tokenUserId = req.user.id;
  const requestedId = parseInt(req.params.userId);
  if (tokenUserId !== requestedId) return res.status(403).json({ error: "Access denied" });

  const updates = await prisma.dailyUpdate.findMany({ where: { userId: requestedId } });
  res.json(updates);
});

module.exports = router;
