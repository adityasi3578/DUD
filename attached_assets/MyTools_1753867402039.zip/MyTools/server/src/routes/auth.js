const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { PrismaClient } = require("@prisma/client");
const authenticateToken = require("../middleware/auth");

const prisma = new PrismaClient();
const router = express.Router();

// 🔐 Register a new user
router.post("/register", async (req, res) => {
  const { email, password, name } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({ data: { email, passwordHash: hashed, name } });
  res.json(user);
});

// 🔐 Login endpoint
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });

  if (!user || !await bcrypt.compare(password, user.passwordHash)) {
    return res.status(401).json({ error: "Invalid credentials" });
  }

  const token = jwt.sign(
    { id: user.id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: "1d" }
  );

  res.json({ token });
});

// 🆕 Signup endpoint (used in frontend)
router.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return res.status(400).json({ error: 'Email already in use' });

    const hashed = await bcrypt.hash(password, 10);
    const newUser = await prisma.user.create({
      data: { name, email, passwordHash: hashed },
    });

    res.status(201).json({ message: 'User created', userId: newUser.id });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// 🆕 ✅ Step 5: Update Name
router.put("/update-name", authenticateToken, async (req, res) => {
  const { name } = req.body;

  try {
    const updated = await prisma.user.update({
      where: { id: req.user.id },
      data: { name },
    });

    res.json({ name: updated.name });
  } catch (err) {
    console.error('Update name error:', err);
    res.status(500).json({ error: "Update failed" });
  }
});

router.get("/profile", authenticateToken, async (req, res) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json({ name: user.name, email: user.email });
  } catch (err) {
    console.error("Profile fetch error:", err);
    res.status(500).json({ error: "Internal error" });
  }
});


module.exports = router;
