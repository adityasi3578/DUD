const express = require("express");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const authenticateToken = require("../middleware/auth");
const router = express.Router();

function requireAdmin(req, res, next) {
  const user = req.user;
  if (user?.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  next();
}

router.get("/", authenticateToken, requireAdmin, async (req, res) => {
  const { date, userId } = req.query;
  const where = {};
  if (date) where.date = new Date(date);
  if (userId) where.userId = parseInt(userId);
  const updates = await prisma.dailyUpdate.findMany({
    where,
    include: { user: true }
  });
  res.json(updates);
});

router.post("/:id/:action", authenticateToken, requireAdmin, async (req, res) => {
  const { id, action } = req.params;
  if (!["approved", "rejected"].includes(action)) return res.status(400).json({ error: "Invalid action" });
  const update = await prisma.dailyUpdate.update({
    where: { id: parseInt(id) },
    data: { status: action }
  });
  res.json(update);
});

module.exports = router;
