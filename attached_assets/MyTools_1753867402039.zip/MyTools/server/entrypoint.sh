#!/bin/sh

echo "🔁 Waiting for PostgreSQL to be ready..."
until nc -z db 5432; do
  sleep 2
done
echo "✅ PostgreSQL is up."

echo "📦 Running Prisma migrate..."
npx prisma migrate dev --name init --skip-seed

echo "🚀 Starting server..."
npm run dev
